var childHight=53;
function displayIfChildIsAbleToRideTheRollerCoaster();
    if 
        (childHight > 52) {
        console.log("Get on that ride kid");
    } else 
        (childHight() < 52);{
        console.log("Sorry kiddo. Maybe next year.");
    }  

