function logInOut(element){
    console.log(element);
    element.innerText = 'Logout';
}

function removeButton(element){
    var elem = document.getElementById("myDiv");
    elem.parentNode.removeChild(elem);}

function likeAlert(){
    alert("Ninja was liked")
}

// var elem = document.getElementById("myDiv");
//     elem.parentNode.removeChild(elem);