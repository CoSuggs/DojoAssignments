var pizza = {
crustType: ["deep dish", "thin crust", "hand tossed"],
sauceType: ["traditional", "white sauce", "marinara"],
cheese: ["mozzarella", "feta", "four cheese"],
toppings: ["pepperoni", "sausage", "mushrooms", "olives", "onions"]
}

function pizzaOven(crustType, sauceType, cheese, toppings){
 var pizza = {};
    pizza.crustType = crustType;
    pizza.sauceType = sauceType;
    pizza.cheese = cheese;
    pizza.toppings = toppings;
    return pizza;
}

var p1 = pizzaOven("deep dish", "traditional", "mozzarella", ["pepperoni", "sausage"]);
console.log(p1);

var p2 = pizzaOven("hand tossed", "marinara", ["mozzarella", "feta"], ["mushrooms", "olives", "onions"]);
console.log(p2);

var p3 = pizzaOven("hand tossed", "white sauce", "mozzarella", ["pepperoni", "sausage", "mushrooms", "olives"]);
console.log(p3);

var p4 = pizzaOven("thin crust", "traditional", "four cheese", ["pepperoni", "olives"]);
console.log(p4);