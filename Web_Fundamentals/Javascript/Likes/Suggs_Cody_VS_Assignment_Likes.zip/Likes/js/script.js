var countOne = 9;
var countElementOne = document.querySelector('#likesOne');

function addLikesOne(){
    countOne++;
    countElementOne.innerText = countOne + " like(s)";
    console.log(countOne);
}


var countTwo = 12;
var countElementTwo = document.querySelector('#likesTwo');

function addLikesTwo(){
    countTwo++;
    countElementTwo.innerText = countTwo + " like(s)";
    console.log(countTwo);
}


var countThree = 9;
var countElementThree = document.querySelector('#likesThree');

function addLikesThree(){
    countThree++;
    countElementThree.innerText = countThree + " like(s)";
    console.log(countThree);
}


