from flask import Flask
app = Flask(__name__)

DATABASE = 'user_db'