from unicodedata import name
from flask import Flask
app = Flask(__name__)

    # THIS WILL MOVE!!!

@app.route('/')  # is a method attached to this flask
def hello_world():
    return 'Hello World!'

@app.route('/dojo')
def dojo():
    return 'Dojo'

@app.route('/say/<name>')
def say_name(name):
    return "Hi "+ str(name)

@app.route('/repeat/<num>/<word>')
def repeat_num(num, word):
    return (str(word)+" ")* int(num)

@app.route('/<rndm>')
def rndm(rndm):
    if rndm != dojo() or say_name() or repeat_num() :
        return "Sorry! No response. Try again"
        # END OF MOVING CODE

if __name__ == "__main__":
    app.run(debug=True)
