public class GorillaTest{
    public static void main(String[] args){
        Gorilla babyKong = new Gorilla();
        babyKong.throwSomething();
        babyKong.throwSomething();
        babyKong.throwSomething();
        babyKong.eatBananas();
        babyKong.eatBananas();
        babyKong.climb();
    }
}
