class FirstProgram{
    public static void main(String[] args){
        System.out.println("My name is Cody Suggs.");
        System.out.println("I am 29 years old.");
        System.out.println("My hometown is Camano Island, WA.");
    }
}