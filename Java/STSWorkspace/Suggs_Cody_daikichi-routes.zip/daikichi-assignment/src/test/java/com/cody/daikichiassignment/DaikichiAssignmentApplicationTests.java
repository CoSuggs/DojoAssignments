package com.cody.daikichiassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichiAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
