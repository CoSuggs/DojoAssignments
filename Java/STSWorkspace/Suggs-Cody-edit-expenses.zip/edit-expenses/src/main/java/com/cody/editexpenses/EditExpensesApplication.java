package com.cody.editexpenses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EditExpensesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EditExpensesApplication.class, args);
	}

}
