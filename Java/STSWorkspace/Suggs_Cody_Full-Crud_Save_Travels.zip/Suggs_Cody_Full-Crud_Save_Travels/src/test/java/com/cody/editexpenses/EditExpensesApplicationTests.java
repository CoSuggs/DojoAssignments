package com.cody.editexpenses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EditExpensesApplicationTests {

	@Test
	void contextLoads() {
	}

}
