class Ninja {
    constructor(name, health = 100, attributes = { "speed": 3, "strength": 3 }) {
        this.name = name;
        this.health = health;
        this.attributes = attributes
    }
    sayName(){
        console.log(this.name);
    }
    showStats(ninja){
        console.log('name is', this.name,'health is', this.health,'attributes are', this.attributes);
    }
    drinkSake(){
        console.log(this.name, 'drank some sake increasing their health by 10 for a total of',this.health+10);
    }
}

const ninja1 = new Ninja("bryon");
ninja1.sayName();
ninja1.showStats();
ninja1.drinkSake();