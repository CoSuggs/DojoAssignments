import React from 'react'
import axios from 'axios';
import { Route } from 'react-router-dom';

const ProductList = (props) => {
    return (
        <div>
            {props.products.map((product, i) =>
                <li>
                    <a key={i} href={`./product/${product._id}`}>{product.title}</a>
                </li>
            )}
        </div>
    )
}

export default ProductList;

