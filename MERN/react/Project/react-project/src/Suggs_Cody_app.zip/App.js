// import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Hello Dojo</h1>
        <h2>
          Things I need to do:
        </h2>
        <li>Learn React</li>
        <li>Climb Mount Everest</li>
        <li>Run a marathon</li>
        <li>feed the dogs</li>
      </header>
    </div>
  );
}

export default App;
